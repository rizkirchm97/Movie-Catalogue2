package com.rizki.moviecatalogue.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}