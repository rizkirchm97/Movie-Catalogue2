package com.rizki.moviecatalogue.ui.detail.tvshows

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.request.RequestOptions
import com.rizki.moviecatalogue.R
import com.rizki.moviecatalogue.data.source.local.entity.TvShowEntity
import com.rizki.moviecatalogue.databinding.ActivityDetailTvShowsBinding
import com.rizki.moviecatalogue.databinding.ContentDetailTvShowsBinding
import com.rizki.moviecatalogue.viewmodel.ViewModelFactory
import com.rizki.moviecatalogue.vo.Status

class DetailTvShowsActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_TVSHOWS = "extra_tv_shows"
    }

    private lateinit var contentDetailTvShowsBinding: ContentDetailTvShowsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val activityDetailTvShowsBinding = ActivityDetailTvShowsBinding.inflate(layoutInflater)
        contentDetailTvShowsBinding = activityDetailTvShowsBinding.detailContentTvShows
        setContentView(activityDetailTvShowsBinding.root)

        val factory = ViewModelFactory.getInstance(this)
        val viewModel = ViewModelProvider(this, factory)[DetailTvShowsViewModel::class.java]

        setSupportActionBar(activityDetailTvShowsBinding.toolbarTvShows)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val extras = intent.extras
        if (extras != null) {
            val tvShowsId = extras.getString(EXTRA_TVSHOWS)
            if (tvShowsId != null) {

                viewModel.setSelectedTvShows(tvShowsId)

                viewModel.tvShows.observe(this, { detailTvSHow ->
                    if (detailTvSHow != null) {
                        when (detailTvSHow.status) {
                            Status.LOADING -> activityDetailTvShowsBinding.progressBar.visibility = View.VISIBLE
                            Status.SUCCESS -> if (detailTvSHow.data != null) {
                                activityDetailTvShowsBinding.progressBar.visibility = View.GONE
                                activityDetailTvShowsBinding.progressBar.visibility = View.VISIBLE

                                populateTvShow(detailTvSHow.data)
                            }
                            Status.ERROR -> {
                                activityDetailTvShowsBinding.progressBar.visibility = View.GONE
                                Toast.makeText(applicationContext, "Something went wrong", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                })
            }
        }
    }

    private fun populateTvShow(tvShowsEntity: TvShowEntity) {
        contentDetailTvShowsBinding.tvDetailTitleTvShows.text = tvShowsEntity.title
        contentDetailTvShowsBinding.tvDetailGenreTvShows.text = tvShowsEntity.genre
        contentDetailTvShowsBinding.tvDetailTtTvShows.text = tvShowsEntity.totalTime
        contentDetailTvShowsBinding.tvDetailNetworkTvShows.text = tvShowsEntity.network
        contentDetailTvShowsBinding.tvDetailQuote.text = tvShowsEntity.quote
        contentDetailTvShowsBinding.tvDetailOverview.text = tvShowsEntity.overview

        Glide.with(this)
            .load(tvShowsEntity.imagePath)
            .transform(RoundedCorners(20))
            .apply(RequestOptions.placeholderOf(R.drawable.ic_loading))
            .error(R.drawable.ic_error)
            .into(contentDetailTvShowsBinding.imgPosterTvShows)
    }
}