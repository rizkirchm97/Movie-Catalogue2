package com.rizki.moviecatalogue.ui.detail.movies

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.request.RequestOptions
import com.rizki.moviecatalogue.R
import com.rizki.moviecatalogue.data.source.local.entity.MovieEntity
import com.rizki.moviecatalogue.databinding.ActivityDetailMoviesBinding
import com.rizki.moviecatalogue.databinding.ContentDetailMoviesBinding
import com.rizki.moviecatalogue.viewmodel.ViewModelFactory
import com.rizki.moviecatalogue.vo.Status

class DetailMoviesActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_MOVIES = "extra_movies"
    }

    private lateinit var contentDetailMoviesBinding: ContentDetailMoviesBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val activityDetailBinding = ActivityDetailMoviesBinding.inflate(layoutInflater)
        contentDetailMoviesBinding = activityDetailBinding.detailContentMovies
        setContentView(activityDetailBinding.root)

        val factory = ViewModelFactory.getInstance(this)
        val viewModel = ViewModelProvider(this, factory)[DetailMoviesViewModel::class.java]

        setSupportActionBar(activityDetailBinding.toolbarMovies)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val extras = intent.extras
        if (extras != null) {
            val moviesId = extras.getString(EXTRA_MOVIES)
            if (moviesId != null) {

                viewModel.setSelectedMovies(moviesId)
                viewModel.movie.observe(this, { detailMovie ->
                    if (detailMovie != null) {
                        when (detailMovie.status) {
                            Status.LOADING -> activityDetailBinding.progressBar.visibility = View.VISIBLE
                            Status.SUCCESS -> if (detailMovie.data != null) {
                                activityDetailBinding.progressBar.visibility = View.GONE
                                activityDetailBinding.progressBar.visibility = View.VISIBLE

                                populateMovies(detailMovie.data)
                            }
                            Status.ERROR -> {
                                activityDetailBinding.progressBar.visibility = View.GONE
                                Toast.makeText(applicationContext, "Something went wrong", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                })

            }
        }
    }

    private fun populateMovies(moviesEntity: MovieEntity) {
        contentDetailMoviesBinding.tvDetailTitle.text = moviesEntity.title
        contentDetailMoviesBinding.tvDetailRd.text = moviesEntity.releaseDate
        contentDetailMoviesBinding.tvDetailGenre.text = moviesEntity.genre
        contentDetailMoviesBinding.tvDetailTt.text = moviesEntity.totalTime
        contentDetailMoviesBinding.tvDetailQuote.text = moviesEntity.quotes
        contentDetailMoviesBinding.tvDetailOverview.text = moviesEntity.overview

        Glide.with(this)
            .load(moviesEntity.imagePath)
            .transform(RoundedCorners(20))
            .apply(RequestOptions.placeholderOf(R.drawable.ic_loading))
            .error(R.drawable.ic_error)
            .into(contentDetailMoviesBinding.imgPoster)

    }
}