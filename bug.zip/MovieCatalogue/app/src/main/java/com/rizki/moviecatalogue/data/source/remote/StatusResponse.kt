package com.rizki.moviecatalogue.data.source.remote

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}